package com.example.degree_receiving_activity;

public class Logindata {
    int UserId;
    String  UserName;
    String UserPassword;
    String UserType;

    public Logindata(int userId, String userName, String userPassword, String userType) {
        UserId = userId;
        UserName = userName;
        UserPassword = userPassword;
        UserType = userType;
    }

    public int getUserId() {
        return UserId;
    }

    public String getUserName() {
        return UserName;
    }

    public String getUserPassword() {
        return UserPassword;
    }

    public String getUserType() {
        return UserType;
    }
}
