package com.example.degree_receiving_activity;

public class
StudentLogin {


}
