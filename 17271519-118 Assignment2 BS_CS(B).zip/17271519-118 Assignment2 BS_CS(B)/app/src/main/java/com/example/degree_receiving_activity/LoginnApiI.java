package com.example.degree_receiving_activity;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface LoginnApiI {
    @GET("api/login")
    Call<List<Logindata>> getAllStudentLogin();
    @POST("api/login")
    Call<Logindata> sendpost2(
            @Field("Id")int id,
            @Field("name")String title,
            @Field("password")String text,
            @Field("type")String type
    );
}
