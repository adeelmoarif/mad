package com.example.degree_receiving_activity;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class custumRVAdpter extends RecyclerView.Adapter<custumRVAdpter.custumHolder> {

List<User> list =new ArrayList<User>();
//public static HashMap<String,User> userHashMap1=new HashMap<String, User>();

    MyonclickLisner myonclickLisner;

    public custumRVAdpter(HashMap<String,User> userHashMap2, MyonclickLisner myonclickLisner1){
        List<User> beans =
                new ArrayList<User>(userHashMap2.values());
       list=beans;
        this.myonclickLisner=myonclickLisner1;
    }


    @NonNull
    @Override
    public custumHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater=LayoutInflater.from(parent.getContext());
        View v=layoutInflater.inflate(R.layout.custum_rv,parent,false);
        return new custumHolder(v,myonclickLisner);
    }

    @Override
    public void onBindViewHolder(@NonNull custumHolder holder, int position) {int s1;

                User u = list.get(position);
                holder.subtxt.setText(u.getSubject());
                holder.commtxt.setText(u.getComment());
                holder.statustxt.setText(u.getStatus());


    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class custumHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
TextView subtxt,commtxt,statustxt;
MyonclickLisner myonclickLisner;
        public custumHolder(@NonNull View itemView, MyonclickLisner myonclickLisner) {
            super(itemView);
            subtxt=itemView.findViewById(R.id.subject);
            commtxt =itemView.findViewById(R.id.comment);
            statustxt=itemView.findViewById(R.id.status);
            this.myonclickLisner=myonclickLisner;
            itemView.setOnClickListener(this::onClick);

        }

        @Override
        public void onClick(View v) {
            User user=list.get(getAdapterPosition());
            myonclickLisner.getListen(user.getUid());
        }
    }

    interface MyonclickLisner{
        void getListen(String possition);
    }
}
