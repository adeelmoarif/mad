package com.example.degree_receiving_activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity implements custumRVAdpter.MyonclickLisner {
    public static List<StudentData> studentDataList=new ArrayList<>();
    public static List<Logindata> studentlogINList=new ArrayList<>();
    AlertDialog.Builder crateDialog;
    Retrofit retrofit;
    DatePickerDialog datePickerDialog;
    AlertDialog showDialog;
    static String id;
    static String type_of_id;
    static String Nuser;
    static int position;
    RecyclerView rc;
    Button year, btn, signup;
    String username, tpye, password;
    EditText nametxt, lastnametxt, subtxt, degreetxt,statustxt,commenttxt,idctxt, contectnumbertxt, adresstxt, usernametxt, passwordtxt;
    TextView datetxt;
    Spinner degree, userType;
    List<String> degreeList, userTypeList;
    ArrayAdapter degreeAdpter, userTypeAdpter;
    boolean isSignIn = false;
    CustumDataBase custumDataBase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        isSignIn = false;
        custumDataBase = new CustumDataBase(MainActivity.this);
        rc = findViewById(R.id.rv);
        retrofit=new Retrofit.Builder()
                .baseUrl("https://10.106.246.118:44359/api/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        Setretrofit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int y;
        y = type_of_id.compareTo("admin");

        if (item.getItemId() == R.id.createapplication) {
            if(y==0){ Show_Alert("warring","You cant add create application only Student do");}
            else {
                ShowApplicationDialog();
            }

        } else if (item.getItemId() == R.id.showapplication) {
            // ShowData();

            if (y == 0) {
                ShowDataAlldata();
                StudentRVDAta();
            } else {
                ShowData();
                StudentRVDAta();
            }
        }
       /* else if(item.getItemId()==R.id.Addcomment){
            if (y == 0) {
               showTOAdmin(position);
            } else {
                Show_Alert("warring","You cant add comment only admin do");
            }

        }*/


        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();

        LoginDialog();

    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i("issingginonStop", "" + isSignIn);
        isSignIn = false;
    }

    @Override
    protected void onRestart() {
        super.onRestart();

    }

    @Override
    protected void onStart() {
        super.onStart();

        // ShowData();
    }

    void LoginDialog() {
        if (!isSignIn) {
            crateDialog = new AlertDialog.Builder(MainActivity.this);

            //gets Items form the views
            View view = getLayoutInflater().inflate(R.layout.signin, null);
            usernametxt = view.findViewById(R.id.username);
            passwordtxt = view.findViewById(R.id.password);
            userType = view.findViewById(R.id.typespinner);
         //   signup = view.findViewById(R.id.signup);

            /// signuppp



            userTypeList = new ArrayList<String>();
            userTypeList.add("Select");
            userTypeList.add("admin");
          
            userTypeList.add("student");
            userTypeAdpter = new ArrayAdapter(getApplicationContext(), R.layout.support_simple_spinner_dropdown_item, userTypeList);
            userTypeAdpter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
            userType.setAdapter(userTypeAdpter);
            crateDialog.setView(view);
            // Click Lisner For Buttons


            crateDialog.setNeutralButton("SignUp", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                  //  boolean isDigits = TextUtils.isDigitsOnly(usernametxt.getText().toString());
                    if(!(usernametxt.getText().toString().trim().isEmpty())&&!(passwordtxt.getText().toString().trim().isEmpty())) {
                        try {
                            custumDataBase.insert_data(usernametxt.getText().toString(), passwordtxt.getText().toString(), userType.getSelectedItem().toString());
                            Toast.makeText(MainActivity.this, "Account is created reopen application", Toast.LENGTH_LONG).show();
                            usernametxt.setText("");
                            passwordtxt.setText("");
                            int eid=0;
                            eid++;
                            try {
                                send_toServer(eid,usernametxt.getText().toString(), passwordtxt.getText().toString(), userType.getSelectedItem().toString());
                            }catch (Exception e)
                            {
                                e.getMessage();
                            }
                            userType.setSelection(0);
                            finish();
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "Account is not created the is some issue with signup", Toast.LENGTH_LONG).show();

                        }
                    }
                    else
                        {
                            Toast.makeText(MainActivity.this, "reopen and  enter all values", Toast.LENGTH_LONG).show();
                            finish();

                        }
                }
            });
            crateDialog.setPositiveButton("SignIn", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    username = usernametxt.getText().toString();
                    password = passwordtxt.getText().toString();
                    tpye = userType.getSelectedItem().toString();
                    if (!isSignIn) {
                        if (checkuser()) {
                            isSignIn = true;
                            showDialog.dismiss();
                            crateDialog = null;
                        } else {

                            showDialog.dismiss();
                            finish();
                            crateDialog = null;
                            isSignIn = false;
                        }
                    }
                }


            });
            crateDialog.setNegativeButton("Cancle", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                    showDialog.dismiss();
                    finish();
                    crateDialog = null;
                    isSignIn = false;
                }
            });
            showDialog = crateDialog.create();
            showDialog.show();
        }
    }

    void ShowApplicationDialog() {
        View view = getLayoutInflater().inflate(R.layout.degree_receiving_form_activity, null);


        /////getdata form the view;

        nametxt = view.findViewById(R.id.name);
        lastnametxt = view.findViewById(R.id.lastname);
        idctxt = view.findViewById(R.id.idcard);
        contectnumbertxt = view.findViewById(R.id.number);
        adresstxt = view.findViewById(R.id.adress);
        datetxt = view.findViewById(R.id.completionyear);
        year = view.findViewById(R.id.completionYearButton);
        subtxt = view.findViewById(R.id.subject);
        degree = view.findViewById(R.id.degree);
        degreeList = new ArrayList<String>();
        degreeList.add("Select");
        degreeList.add("BS_CS");
        degreeList.add("BS_it");
        degreeList.add("BS_SE");
        degreeAdpter = new ArrayAdapter(getApplicationContext(), R.layout.support_simple_spinner_dropdown_item, degreeList);
        degreeAdpter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        degree.setAdapter(degreeAdpter);

        /*
        Date time Button Click
         */
        year.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                datePickerDialog = new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        // Toast.makeText(MainActivity.this,""+month+1,Toast.LENGTH_LONG).show();
                        month = month + 1;
                        datetxt.setText(year + "-" + month + "-" + dayOfMonth);
                    }
                }, Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
                datePickerDialog.show();
            }
        });


        ///// Create Dialog and its events;;;;;


        crateDialog = new AlertDialog.Builder(MainActivity.this);
        crateDialog.setView(view);
        crateDialog.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if(!(nametxt.getText().toString().toString().isEmpty())&&!(lastnametxt.getText().toString().toString().isEmpty())
                &&!(idctxt.getText().toString().toString().isEmpty())&&!(adresstxt.getText().toString().toString().isEmpty())
                &&!(contectnumbertxt.getText().toString().toString().isEmpty())&&!( datetxt.getText().toString().isEmpty())
                        &&!( subtxt.getText().toString().isEmpty())&&!( degree.getSelectedItem().toString().equals("Select"))) {
                    if(custumDataBase.insert_data_User(id,
                            nametxt.getText().toString(), lastnametxt.getText().toString(),
                            idctxt.getText().toString(), adresstxt.getText().toString(), contectnumbertxt.getText().toString(), datetxt.getText().toString()
                            , degree.getSelectedItem().toString(), subtxt.getText().toString()))
                    {
                        showDialog.dismiss();
                        crateDialog = null;
                        Toast.makeText(MainActivity.this, "Data is  save", Toast.LENGTH_LONG).show();
                    }
                    else {
                        Toast.makeText(MainActivity.this, "Data is all Ready exist with same id", Toast.LENGTH_LONG).show();

                    }



                }
                else{
                    //////////////////////////////
                    Toast.makeText(MainActivity.this, "Data is not save", Toast.LENGTH_LONG).show();
                    showDialog.dismiss();
                    crateDialog = null;
                }
            }
        });
        showDialog = crateDialog.create();
        showDialog.show();

    }

    void ShowData() {
        Cursor cur = custumDataBase.ShowData_application(id);
        int i;
        StringBuffer stringBuffer = new StringBuffer();
        if (cur.getCount() == 0) {
            Show_Alert("Error", "Nothing to show");
            return;
        }
        while ((cur.moveToNext())) {

            stringBuffer.append("ID: " + cur.getString(0) + "\n");
            stringBuffer.append("Name: " + cur.getString(1) + "\n");
            stringBuffer.append("Father: " + cur.getString(2) + "\n");
            stringBuffer.append("idcard: " + cur.getString(3) + "\n");
            stringBuffer.append("adress: " + cur.getString(4) + "\n");
            stringBuffer.append("number: " + cur.getString(5) + "\n");
            stringBuffer.append("subject: " + cur.getString(6) + "\n");
            stringBuffer.append("passingyear: " + cur.getString(7) + "\n");
            stringBuffer.append("dregee: " + cur.getString(8) + "\n");
            stringBuffer.append("comment: " + cur.getString(9) + "\n");
            stringBuffer.append("status: " + cur.getString(10) + "\n");
            stringBuffer.append("dateof subb: " + cur.getString(11) + "\n");
            if(!(User.userHashMap.containsKey(cur.getString(0)))) {
                User.userHashMap.put(cur.getString(0), new User(cur.getString(1),
                        cur.getString(8), cur.getString(0),
                        cur.getString(9), cur.getString(10),
                        cur.getString(6),
                        cur.getString(11),
                        cur.getString(2), cur.getString(3),
                        cur.getString(4), cur.getString(7), cur.getString(5)));
            }

           /* User.userDegreeList.add(new User(cur.getString(1),
                    cur.getString(8), cur.getString(0),
                    cur.getString(9), cur.getString(10),
                    cur.getString(6),
                    cur.getString(11),
                    cur.getString(2),cur.getString(3),
                    cur.getString(4),cur.getString(7),cur.getString(5)));

            */


        }

        //  Show_Alert("Data", stringBuffer.toString());
    }

    void ShowData1() {

        Cursor cur = custumDataBase.ShowData();

        while ((cur.moveToNext())) {
            User.userList.add(new User(cur.getString(1), cur.getString(2), cur.getString(3), cur.getString(0)));
            Log.i("c", "" + User.userList.size());
        }


    }

    void Show_Alert(String Title, String Message) {
        android.app.AlertDialog.Builder Alert = new android.app.AlertDialog.Builder(MainActivity.this);
        Alert.setCancelable(true);
        Alert.setTitle(Title);
        Alert.setMessage(Message);
        Alert.show();

    }


/*void addStudentFaregment(){
    studentFragment s= new studentFragment();
    FragmentManager fragmentManager=getSupportFragmentManager();
    FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
    fragmentTransaction.add(R.id.myfragmentlaout,s,null);
    fragmentTransaction.addToBackStack(null);
    fragmentTransaction.commit();
}*/

    void StudentRVDAta() {

        int a23=type_of_id.compareTo("admin");
        if(a23==0)
        {
            User.userHashMap.clear();
            ShowDataAlldata();
            rc.setAdapter(new custumRVAdpter(User.userHashMap,this));
            rc.setLayoutManager(new LinearLayoutManager(MainActivity.this));
           // showTOAdmin(possition);
        }
        else
  {
      User.userHashMap.clear();
      ShowData();
      rc.setAdapter(new custumRVAdpter(User.userHashMap,this));
      rc.setLayoutManager(new LinearLayoutManager(MainActivity.this));
           // showTOuser(possition);
  }

    }

    boolean checkuser() {
        ShowData1();
        int a1, a2, a3;
        boolean b = false;

        for (User user : User.userList) {
            a1 = user.getName().compareTo(username);
            a2 = user.password.compareTo(password);
            a3 = user.type.compareTo(tpye);
            if (a1 == 0 && a2 == 0 & a3 == 0) {
                id = user.getUid();
                type_of_id = user.getType();
                Nuser = user.getName();
                b = true;
                break;
            } else {
                b = false;
            }

        }
        return b;
    }

    void ShowDataAlldata() {
        Cursor cur = custumDataBase.ShowDataall_application();
        int i;
        StringBuffer stringBuffer = new StringBuffer();
        if (cur.getCount() == 0) {
            Show_Alert("Error", "Nothing to show");
            return;
        }
        while ((cur.moveToNext())) {

            stringBuffer.append("ID: " + cur.getString(0) + "\n");
            stringBuffer.append("Name: " + cur.getString(1) + "\n");
            stringBuffer.append("Father: " + cur.getString(2) + "\n");
            stringBuffer.append("idcard: " + cur.getString(3) + "\n");
            stringBuffer.append("adress: " + cur.getString(4) + "\n");
            stringBuffer.append("number: " + cur.getString(5) + "\n");
            stringBuffer.append("subject: " + cur.getString(6) + "\n");
            stringBuffer.append("passingyear: " + cur.getString(7) + "\n");
            stringBuffer.append("dregee: " + cur.getString(8) + "\n");
            stringBuffer.append("comment: " + cur.getString(9) + "\n");
            stringBuffer.append("status: " + cur.getString(10) + "\n");
            stringBuffer.append("dateof subb: " + cur.getString(11) + "\n");
            if(!(User.userHashMap.containsKey(cur.getString(0)))) {
                User.userHashMap.put(cur.getString(0), new User(cur.getString(1),
                        cur.getString(8), cur.getString(0),
                        cur.getString(9), cur.getString(10),
                        cur.getString(6),
                        cur.getString(11),
                        cur.getString(2), cur.getString(3),
                        cur.getString(4), cur.getString(7), cur.getString(5)));
            }
            /*
            User.userDegreeList.add(new User(cur.getString(1),
                    cur.getString(8), cur.getString(0),
                    cur.getString(9), cur.getString(10),
                    cur.getString(6),
                    cur.getString(11),
                    cur.getString(2),cur.getString(3),
                    cur.getString(4),cur.getString(7),cur.getString(5)));

             */


        }

     //   Show_Alert("Data", stringBuffer.toString());
    }


    void showTOuser(String poition) {
        ShowData();
        View view = getLayoutInflater().inflate(R.layout.show_for_update, null);
      //  User u=User.userDegreeList.get(poition);
        User u=User.userHashMap.get(poition);
        nametxt = view.findViewById(R.id.name);
        lastnametxt = view.findViewById(R.id.lastname);
        idctxt = view.findViewById(R.id.idcard);
        contectnumbertxt = view.findViewById(R.id.number);
        adresstxt = view.findViewById(R.id.adress);
        datetxt = view.findViewById(R.id.completionyear);
        year = view.findViewById(R.id.completionYearButton);
        subtxt = view.findViewById(R.id.subject);
        degree = view.findViewById(R.id.degree);
        nametxt.setText(u.getName());
        lastnametxt.setText(u.getLname());
        idctxt.setText(u.getiDCard());
        contectnumbertxt.setText(u.getNumber());
        adresstxt.setText(u.getAdress());
        datetxt.setText(u.getPassying());
        degreetxt=view.findViewById(R.id.degree1);
        degreetxt.setText(u.getType());
        subtxt.setText(u.getSubject());




        crateDialog = new AlertDialog.Builder(MainActivity.this);
        crateDialog.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
        custumDataBase.Update_data1(u.getUid(),
        nametxt.getText().toString(), lastnametxt.getText().toString(),
        idctxt.getText().toString(), adresstxt.getText().toString(), contectnumbertxt.getText().toString(), datetxt.getText().toString()
        , degreetxt.getText().toString(), subtxt.getText().toString());
            showDialog.dismiss();
            crateDialog=null;
                StudentRVDAta();
            }

        });
        crateDialog.setNegativeButton("Cancle", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                showDialog.dismiss();
                crateDialog=null;
            }
        });
crateDialog.setView(view);
crateDialog.setTitle("IF you Change any thing the Save it...");
showDialog=crateDialog.create();
showDialog.show();
    }


    @Override
    public void getListen(String possition) {
        int a23=type_of_id.compareTo("admin");
        if(a23==0)
        showTOAdmin(possition);
        else
            showTOuser(possition);
    }
    void showTOAdmin(String poition) {
        ShowDataAlldata();
        View view = getLayoutInflater().inflate(R.layout.showdata, null);
        //User u=User.userDegreeList.get(poition);
        User u=User.userHashMap.get(poition);
        nametxt = view.findViewById(R.id.name);
        lastnametxt = view.findViewById(R.id.lastname);
        idctxt = view.findViewById(R.id.idcard);
        contectnumbertxt = view.findViewById(R.id.number);
        adresstxt = view.findViewById(R.id.adress);
        datetxt = view.findViewById(R.id.completionyear);
        year = view.findViewById(R.id.completionYearButton);
        subtxt = view.findViewById(R.id.subject);
        statustxt = view.findViewById(R.id.status);
        commenttxt=view.findViewById(R.id.comment);
        degree = view.findViewById(R.id.degree);
        nametxt.setText(u.getName());
        lastnametxt.setText(u.getLname());
        idctxt.setText(u.getiDCard());
        contectnumbertxt.setText(u.getNumber());
        adresstxt.setText(u.getAdress());
        datetxt.setText(u.getPassying());
        degreetxt=view.findViewById(R.id.degree1);
        degreetxt.setText(u.getType());
        subtxt.setText(u.getSubject());
        commenttxt.setText(u.getComment());
        statustxt.setText(u.getStatus());


        crateDialog = new AlertDialog.Builder(MainActivity.this);
        crateDialog.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                custumDataBase.Update_data(u.getUid(),
                        nametxt.getText().toString(), lastnametxt.getText().toString(),
                        idctxt.getText().toString(), adresstxt.getText().toString(), contectnumbertxt.getText().toString(), datetxt.getText().toString()
                        , degreetxt.getText().toString(), subtxt.getText().toString(),commenttxt.getText().toString(),statustxt.getText().toString());
                StudentRVDAta();

                showDialog.dismiss();
                crateDialog=null;
                Log.i("iid",u.getUid());
            }

        });
        crateDialog.setNegativeButton("Cancle", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                showDialog.dismiss();
                crateDialog=null;
            }
        });
        crateDialog.setView(view);
      //  crateDialog.setTitle("Save the Changes");
        showDialog=crateDialog.create();
        showDialog.show();
    }
    void Setretrofit()
    {
        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl("https://10.106.246.118:44359/")
                .addConverterFactory(GsonConverterFactory.create() )
                .build();
        StudentdataI api=retrofit.create(StudentdataI.class);
        Call<List<StudentData>> listCall=api.getAllStudentDegreeRequest();
        // to execute in other thread....
        listCall.enqueue(new Callback<List<StudentData>>() {
            @Override
            public void onResponse(Call<List<StudentData>> call, Response<List<StudentData>> response) {
                if ((!response.isSuccessful())) {
                    Log.i("Size1", String.valueOf(response.message()));
                    return;
                }
                List<StudentData> postList = response.body();
                Log.i("Size2", String.valueOf(postList.size()));
                for (StudentData p : postList) {
                    {
                        try {


                            studentDataList.add(new StudentData(p.Userid, p.UserName, p.UserLastName, p.Cnic, p.Adress, p.Degree, p.Subject, p.PassingYear, p.Comment, p.Status));
                        } catch (Exception e) {
                            e.getMessage();
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<List<StudentData>> call, Throwable t) {
                Log.i("Size4",String.valueOf(t.getMessage()));
            }
        });
    }



    void LoginSetretrofit()
    {
        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl("https://10.106.246.118:44359/")
                .addConverterFactory(GsonConverterFactory.create() )
                .build();
        LoginnApiI api=retrofit.create(LoginnApiI.class);
        Call<List<Logindata>> listCall=api.getAllStudentLogin();
        // to execute in other thread....
        listCall.enqueue(new Callback<List<Logindata>>() {
            @Override
            public void onResponse(Call<List<Logindata>> call, Response<List<Logindata>> response) {
                if ((!response.isSuccessful())) {
                    Log.i("Size1", String.valueOf(response.message()));
                    return;
                }
                List<Logindata> postList = response.body();

                Log.i("Size2", String.valueOf(postList.size()));
                for (Logindata p : postList) {
                    {
                        try {
                            studentlogINList.add(new Logindata(p.getUserId(),p.getUserName(),p.getUserPassword(),p.getUserType()));
                        } catch (Exception e) {
                            e.getMessage();
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<List<Logindata>> call, Throwable t) {
                Log.i("Size4",String.valueOf(t.getMessage()));
            }
        });
    }

    void send_toServer(int id ,String name,String password,String Type){
        Logindata post1=new Logindata(id, name,password,Type);
        LoginnApiI api=retrofit.create(LoginnApiI.class);
        Call<Logindata> postCall=api.sendpost2(id, name,password,Type);
        postCall.enqueue(new Callback<Logindata>() {
            @Override
            public void onResponse(Call<Logindata> call, Response<Logindata> response) {
                if(!(response.isSuccessful()))
                {
                    return;
                }
                Logindata p=response.body();



            }

            @Override
            public void onFailure(Call<Logindata> call, Throwable t) {

            }
        });
    }
    void send_toServerForDelete(int id )
    {

        StudentdataI api=retrofit.create(StudentdataI.class);
        Call<StudentData> postCall=api.delete(id);
        postCall.enqueue(new Callback<StudentData>() {
            @Override
            public void onResponse(Call<StudentData> call, Response<StudentData> response) {
                if(!(response.isSuccessful()))
                {
                    return;
                }
                StudentData p=response.body();



            }

            @Override
            public void onFailure(Call<StudentData> call, Throwable t) {

            }
        });
    }



    void send_toServerForupdate(int id )
    {

        StudentdataI api=retrofit.create(StudentdataI.class);
        Call<StudentData> postCall=api.delete(id);
        postCall.enqueue(new Callback<StudentData>() {
            @Override
            public void onResponse(Call<StudentData> call, Response<StudentData> response) {
                if(!(response.isSuccessful()))
                {
                    return;
                }
                StudentData p=response.body();



            }

            @Override
            public void onFailure(Call<StudentData> call, Throwable t) {

            }
        });
    }



}






