package com.example.degree_receiving_activity;

public class StudentData {
    int Userid;
  public   String UserName;
    String UserLastName;
    String Cnic;
    String Adress;
    String Degree;
    String Subject;
    String PassingYear;
    String Comment;
    String Status;

    public StudentData(int userid, String userName, String userLastName, String cnic, String adress, String degree, String subject, String passingYear, String comment, String status) {
        Userid = userid;
        UserName = userName;
        UserLastName = userLastName;
        Cnic = cnic;
        Adress = adress;
        Degree = degree;
        Subject = subject;
        PassingYear = passingYear;
        Comment = comment;
        Status = status;
    }

    public int getUserid() {
        return Userid;
    }

    public String getUserName() {
        return UserName;
    }

    public String getUserLastName() {
        return UserLastName;
    }

    public String getCnic() {
        return Cnic;
    }

    public String getAdress() {
        return Adress;
    }

    public String getDegree() {
        return Degree;
    }

    public String getSubject() {
        return Subject;
    }

    public String getPassingYear() {
        return PassingYear;
    }

    public String getComment() {
        return Comment;
    }

    public String getStatus() {
        return Status;
    }
}
