package com.example.degree_receiving_activity;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.ContactsContract;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class CustumDataBase extends SQLiteOpenHelper {
    String userLoginTable="User_Login";
    private Calendar calendar;
    Context context;
    private SimpleDateFormat dateFormat;
    String studentDataTable="User_Data";
   public String dataBaseName="User_DataBase";
    public CustumDataBase(@Nullable Context context) {

        super(context, "User_DataBase", null, 3);
        this.context=context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
   db.execSQL("create table "+userLoginTable+"(userid integer primary key autoincrement,username text unique,userpassward text,usertype text)");
   db.execSQL("Insert into "+userLoginTable+"(username,userpassward,usertype) values ('admin','admin','admin')");
   db.execSQL("create table "+studentDataTable+"(userid integer unique ,username text ,userlastname text,idcardnumber text,adress text,contectnumber text,Subject text,passingyear text,degress text,comments text ,status text,dateofsubmission text) ");
    }
    public boolean insert_data_User(String id,String username,String lstname,String nic,String add,String conn,String passing,String degre,String sub )
    {
        SQLiteDatabase db = this.getWritableDatabase();


            ContentValues contentValues = new ContentValues();
            contentValues.put("userid", Integer.parseInt(id));
            contentValues.put("username", username);
            contentValues.put("userlastname", lstname);
            contentValues.put("idcardnumber", nic);
            contentValues.put("adress", add);
            contentValues.put("contectnumber", conn);
            contentValues.put("passingyear", passing);
            contentValues.put("degress", degre);
            contentValues.put("Subject", sub);
            calendar = Calendar.getInstance();
            dateFormat = new SimpleDateFormat("MM/dd/yyyy");
            String date = dateFormat.format(calendar.getTime());
            contentValues.put("dateofsubmission", date);
            long result = db.insert(studentDataTable, null, contentValues);
            if(result==-1){
                return false;

            }else {
                return true;
            }

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("drop table if exists  "+userLoginTable);
        db.execSQL("drop table if exists  "+studentDataTable);
        onCreate(db);
    }

    public Cursor ShowLoginData(String name){

        SQLiteDatabase db=this.getWritableDatabase();
       // Cursor c = db.rawQuery("SELECT * FROM " + userLoginTable + " where username = '" + name + "'" , null);
        Cursor c= db.rawQuery( "select * from "+userLoginTable+" WHERE usertype = 'admin'", null );
        return c;
    }
    public Cursor ShowData(){
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor cur=db.rawQuery("select * From "+userLoginTable,null);
        return cur;
    }
    public Cursor ShowData_application(String id){
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor cur=db.rawQuery("select * From "+studentDataTable+" WHERE userid = '"+id+"'",null);
        return cur;
    }
    public Cursor ShowDataall_application(){
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor cur=db.rawQuery("select * From "+studentDataTable,null);
        return cur;
    }
    public void insert_data(String username,String password,String type ){
try{
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("username",username);
        contentValues.put("userpassward",password);
        contentValues.put("usertype",type);
        long result=db.insert(userLoginTable,null,contentValues);

        }catch (Exception e){
    Toast.makeText(this.context, "Error Message", Toast.LENGTH_LONG).show();

}
    }
    public Integer Update_data1(String id,String username,String lstname,String nic,String add,String conn,String passing,String degre,String sub){

        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("userid",Integer.parseInt(id));
        contentValues.put("username",username);
        contentValues.put("userlastname",lstname);
        contentValues.put("idcardnumber",nic);
        contentValues.put("adress",add);
        contentValues.put("contectnumber",conn);
        contentValues.put("passingyear",passing);
        contentValues.put("degress",degre);
        ;calendar = Calendar.getInstance();
        dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        String date = dateFormat.format(calendar.getTime());
        contentValues.put("dateofsubmission",date);
        return db.update(studentDataTable,contentValues,"userid = ?",new String[]{id});
    }

    public Integer Update_data(String id,String username,String lstname,String nic,String add,String conn,String passing,String degre,String sub,String comments,String status){

        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("userid",Integer.parseInt(id));
        contentValues.put("username",username);
        contentValues.put("userlastname",lstname);
        contentValues.put("idcardnumber",nic);
        contentValues.put("adress",add);
        contentValues.put("contectnumber",conn);
        contentValues.put("passingyear",passing);
        contentValues.put("degress",degre);
        contentValues.put("comments",comments);
        contentValues.put("status",status);
        ;calendar = Calendar.getInstance();
        dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        String date = dateFormat.format(calendar.getTime());
        contentValues.put("dateofsubmission",date);
        return db.update(studentDataTable,contentValues,"userid = ?",new String[]{id});
    }

}

