package com.example.degree_receiving_activity;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Url;

public interface StudentdataI {
@GET("api/usersdata")
Call<List<StudentData>> getAllStudentDegreeRequest();
    @POST("api/usersdata")
    Call<StudentData> sendpost2(
            @Field("Id")int id,
            @Field("name")String title,
            @Field("lastname")String lname,
            @Field("type")String type,
            @Field("date")String date,
            @Field("cinc")String cinc,
            @Field("Adress")String Adress,
            @Field("Degree")String Degree,
            @Field("Subject")String Subject,
            @Field("Comment")String Comment,
            @Field("Status")String Status


            );
    @GET
    Call<List<StudentData>> getDelete(@Url String url);
    Call<StudentData> delete(
            @Field("Id")int id);
}
