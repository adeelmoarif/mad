package com.example.degree_receiving_activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class User {
    String name;
    String lname;
    String password;
    String iDCard;
    String adress;
    String passying;
    String type;
    String uid;
    String number;
    String comment="Null";
    String status="Null";
    String subject="Null";
    String Date="Null";
    public static List<User> userList=new ArrayList<User>();
    public static List<User> userDegreeList=new ArrayList<User>();
    public static HashMap<String,User> userHashMap=new HashMap<String, User>();
    public User(String na,String pass,String ty,String id){
        name=na;
        password=pass;
        type=ty;
        uid=id;
    }
    public User(String na,String ty,String id,String c,String ss,String subb,
                String date,String nl,String Card,String adres,String paing,String numb){
        name=na;
        type=ty;
        uid=id;
        comment=c;
        status=ss;
        subject=subb;
        Date=date;
        lname=nl;
        iDCard=Card;
        adress=adres;
        passying=paing;
        number=numb;


    }
    public User(String na,String ty,String id,String subb,
                String date,String nl,String Card,String adres,String paing,String numb){
        name=na;
        type=ty;
        uid=id;
        subject=subb;
        Date=date;
        lname=nl;
        iDCard=Card;
        adress=adres;
        passying=paing;
        number=numb;


    }

    public String getNumber() {
        return number;
    }

    public String getPassying() {
        return passying;
    }

    public String getLname() {
        return lname;
    }

    public String getiDCard() {
        return iDCard;
    }

    public String getAdress() {
        return adress;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getComment() {
        return comment;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getUid() {
        return uid;
    }

    public String getName() {
        return name;
    }

    public String getPassword() {
        return password;
    }

    public String getType() {
        return type;
    }
}
